let url_local;

const LOCAL_PLAYLOG_PATH = "/INFO/ProgrammaticPlaylog";
let PLAYLOG = {
    date_begin: '',
    date_end: '',
    dsp: '',
    id: '',
    device_id: '',
    advertise: '',
    creative_name: '',
    creative_id: '',
    campaign_id: '',
    creative_category: '',
    transaction_id: '',
}

const LABEL = {
    dsp: 'category',
    id: 'titulo',
    advertise: 'texto6',
    creative_name: 'texto7',
    creative_id: 'texto',
    campaign_id: 'texto3',
    creative_category: 'texto5',
}

function parsePlaylog(contentData, playlog) {
    for (const key in LABEL) {
        playlog[key] = contentData.value(LABEL[key]).value;
    }
    return playlog;
}

function start() {
    ebhtml.create2({}, loader => {
        const NO_ERROR = "NOERROR";
        let callback_url;
        loader.autoloaded = false;
        loadLocaisDatas(loader, 'D_LOCAL', 'D_PROGRAMATIC_PLAYER')
            .then(() => {
                let url_local = loader.data('D_PROGRAMATIC_PLAYER').value('TEXTO').value;
                console.log("url_local -> ", url_local)

                // Verifica se urlServer é null, undefined ou uma string vazia
                if (!url_local) {
                    urlServer = 'https://player.nirooh.com/ad/';
                } else {
                    urlServer = url_local;
                }
                console.log("urlServer -> ", urlServer)

                let version = '1.0.6';
                let timeNow = new Date().getTime();
                let screen_id = loader.data('D_LOCAL').value('SCREEN_SYS').value;
                return fetch(`${urlServer}next-asset?version=${version}&screen_id=${screen_id}&cms=inviron&t=${timeNow}`)
            })
            .then(remoteData => remoteData.json())
            .then(remoteData => {
                if (url_local) {
                    console.log(remoteData);
                }
                if (remoteData.status === 'noad') {
                    loader.finished();
                    return Promise.reject(NO_ERROR);
                } else {
                    PLAYLOG.transaction_id = remoteData.transaction_id;
                    callback_url = remoteData.redir + '&t=' + Date.now();
                    callbackstart_url = remoteData.start

                    switch (remoteData.type) {
                        case 'iframe':
                            if (!url_local) {
                                tempo = remoteData.length_in_milliseconds / 1000;
                            } else {
                                tempo = 15;
                            }
                            return Promise.resolve({
                                type: remoteData.type,
                                src: remoteData.ad_iframe,
                                time: tempo,
                            });
                        case 'html':
                            return Promise.resolve({
                                type: remoteData.type,
                                src: remoteData.ad_html,
                                time: 15,
                            });
                        default:
                            return getProgramaticFilesData(remoteData.ad_id);
                    }
                }
            })
            .then((media) => {
                console.log(media);
                switch (media.type) {
                    case 'iframe':
                        playerIframe.source = media.src;
                        if (!url_local) {
                            if (media.time != 0){
                                playerIframe.time = media.time;
                            } else {
                                playerIframe.time = 10;
                            }
                        }
                        return playerIframe.load();
                    case 'html':
                        playerHTML.source = media.src;
                        return playerHTML.load();
                    case 'video':
                        playerVideo.source = media.src;
                        playerVideo.time = media.time;
                        return playerVideo.load();
                    case 'image':
                        playerImage.source = media.src;
                        if (media.time != 0) {
                            playerImage.time = media.time;
                        } else {
                            playerImage.time = 10;
                        }
                        return playerImage.load();
                    default:
                        throw `Type ${media.type} not supported`;
                }
            })
            .then(player => {
                PLAYLOG.date_begin = Date.now();
                loader.loaded();
                if (callbackstart_url != undefined) {
                    recordLog(callbackstart_url);
                }
                return player.play();
            })
            .then(() => {
                return recordLog(callback_url);
            })
            .then(() => loader.finished())
            .catch(reason => reason !== NO_ERROR ? loader.error(reason) : console.log("Ended without error"));
    })
}


function loadLocaisDatas(loader, dataname, dataname_sucundario) {
    return new Promise((resolve, reject) => {
        loader.addData(dataname, true, '', '', 'http://127.0.0.1:13199/CONTENT/DATA');
        loader.addData(dataname_sucundario, true, '', '', 'http://127.0.0.1:13199/CONTENT/DATA');
        loader.load(() => resolve(), message => reject(message))
    })
}


function getProgramaticFilesData(adID) {
    return new Promise((resolve, reject) => {
        ebhtml.create2({}, loader => {

            loader.addData('D_PROGRAMATIC_FILES', true, 'browservalue=0&f_titulo=' + adID, '', 'http://127.0.0.1:13199/CONTENT/DATA');
            loader.nodataiserror = false
            loader.autoloaded = false
            loader.load(() => {
                const programaticData = loader.data('D_PROGRAMATIC_FILES');
                PLAYLOG = parsePlaylog(loader.data('D_PROGRAMATIC_FILES'), PLAYLOG);
                const fileType = programaticData.value('texto4').value.split('/')[0];
                const source = `http://127.0.0.1:13199/FILES/${programaticData.value('foto').value}`;
                return resolve({
                    type: fileType,
                    src: source,
                    time: programaticData.value('price').value,
                });
            }, reason => reject(reason))
        })
    })
}

function recordLog(remoteURL) {
    return new Promise(resolve => {
        let canResolve = true;
        postRemoteLog(remoteURL).then(() => console.log('Remote log recorded'))
            .catch(e => canResolve ? resolve() : canResolve = true)
            .finally(() => canResolve ? resolve() : canResolve = true);
    });
}

function postLocalLog(url) {
    PLAYLOG.date_end = Date.now();

    let headers = new Headers();
    headers.append("key", "a0f333b5-1a1b-429e-bde2-7ba263e802b8");
    headers.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();

    for (const key in PLAYLOG) {
        urlencoded.append(key, PLAYLOG[key]);
    }

    const requestOptionsRedir = {
        method: 'POST',
        headers: headers,
        body: urlencoded,
        redirect: 'follow',
    }

    return fetch(url, requestOptionsRedir);
}

function postRemoteLog(url) {
    var myHeaders = new Headers()
    myHeaders.append("Cookie", "tuuid=0808d769-2cac-4e3f-a744-bf90002cbfbd")
    console.log(url);
    var requestOptionsRedir = {
        mode: 'no-cors',
        method: 'POST',
        headers: myHeaders,
        redirect: 'follow',
    }
    return fetch(url, requestOptionsRedir);
}

var playerIframe = {
    element: document.createElement('iframe'),
    source: "",
    load: () => {
        return new Promise((resolve, reject) => {
            console.log(`Loading iframe for ${playerIframe.source}`);
            if (playerIframe.source === "")
                reject("Empty source for iframe player ")

            playerIframe.element.width = "100%";
            playerIframe.element.height = "100%";
            playerIframe.element.onerror = () => reject("Error loading media");
            playerIframe.element.onload = () => resolve(playerIframe);
            playerIframe.element.src = playerIframe.source;
            document.body.appendChild(playerIframe.element);
        })
    },
    play: () => {
        if (!url_local) {
            tempo = (playerIframe.time * 1000) - 500;
        } else {
            tempo = 14500;
        }
        return new Promise(resolve => {
            const timeout = setTimeout(() => {
                clearTimeout(timeout);
                resolve()
            }, tempo)
        })
    }
}

var playerHTML = {
    element: document.createElement('div'),
    source: "",
    load: () => {
        return new Promise((resolve, reject) => {

            if (playerHTML.source === "")
                reject("Empty source for HTML player");

            playerHTML.element.innerHTML += decodeHTMLEntities(playerHTML.source);
            document.body.appendChild(playerHTML.element);
            resolve(playerHTML);
        })
    },
    play: () => {
        return new Promise(resolve => {
            const timeout = setTimeout(() => {
                clearTimeout(timeout);
                resolve()
            }, 14500)
        })
    }
}

var playerVideo = {
    element: "",
    source: "",
    time: 0,
    load: () => {
        return new Promise((resolve, reject) => {
            playerVideo.element = document.getElementById('video');
            if (playerVideo.source === "")
                reject("Empty source for video player");

            playerVideo.element.onerror = () => reject(`Error on load video ${playerVideo.element.error.code} - ${playerVideo.element.error.message}`);
            playerVideo.element.onloadeddata = () => resolve(playerVideo);
            playerVideo.element.autoplay = true;
            playerVideo.element.src = playerVideo.source;

        })
    },
    play: () => {
        return new Promise((resolve, reject) => {
            let hasFinished = false;

            playerVideo.element.onstalled = () => {
                if (!hasFinished) {
                    hasFinished = true;
                    reject('Video player has failed to fetch data');
                }
            }

            playerVideo.element.onended = () => {
                if (!hasFinished) {
                    hasFinished = true;
                    resolve();
                }
            }

            playerVideo.element.ontimeupdate = () => {
                if (!hasFinished)
                    if (this.currentTime >= (playerVideo.time - 500)) {
                        hasFinished = true;
                        resolve();
                    }
            }
        })
    }
}

var playerImage = {
    element: "",
    source: "",
    time: 0,
    load: () => {
        playerImage.element = document.getElementById('imagem');
        return new Promise((resolve, reject) => {

            if (playerImage.source === "")
                reject("Empty source for HTML player")

            playerImage.element.onload = () => resolve(playerImage);
            playerImage.element.onerror = () => reject(`Error on load image`);
            playerImage.element.src = playerImage.source;
        })
    },
    play: () => {
        return new Promise(resolve => {
            playerImage.element.style.opacity = 1;
            const timeout = setTimeout(() => {
                clearTimeout(timeout);
                resolve()
            }, (playerImage.time * 1000) - 500)
        })
    }
}

window.onload = start;

function decodeHTMLEntities(text) {
    let textArea = document.createElement('textarea');
    textArea.innerHTML = text;
    return textArea.value;
}
