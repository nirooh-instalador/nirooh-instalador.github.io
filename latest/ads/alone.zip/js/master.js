let PLAYLOG = {
    date_begin: '',
    date_end: '',
    dsp: '',
    id: '',
    device_id: '',
    advertise: '',
    creative_name: '',
    creative_id: '',
    campaign_id: '',
    creative_category: '',
    transaction_id: '',
}

function isNullOrEmptyOrUndefined(value) {
    return value == null || value === "" || (Array.isArray(value) && value.length === 0);
}

function start() {
    const NO_ERROR = "NOERROR";
    let callback_url;
    fetch("/ad/screenid")
    .then(remoteData => remoteData.json())
    .then(remoteData => {
        let screen_id = remoteData.id;
        if (isNullOrEmptyOrUndefined(screen_id)) {
            const urlParams = new URLSearchParams(window.location.search);
            screen_id = urlParams.get('screen');
        }
        console.log("marco");
        console.log(screen_id);
        console.log(isNullOrEmptyOrUndefined(screen_id));
        if (isNullOrEmptyOrUndefined(screen_id)) {
            console.log(remoteData.status);
            if (remoteData.status === 'install') {
                console.log("marco");
                document.getElementById("numbers").innerText = remoteData.code;
                document.getElementById("shownumbers").style.display = 'flex';
                return;
            }
        }
//        let urlServer = 'https://player.nirooh.com/ad/';
        let version = '1.0.7';
        let timeNow = new Date().getTime();
        return fetch(`/ad/next-asset?version=${version}&screen_id=${screen_id}&cms=alone&t=${timeNow}`)
    })
    .then(remoteData => remoteData.json())
    .then(remoteData => {
        // console.log(remoteData);
        if(remoteData.status === 'noad') {
            return Promise.reject(NO_ERROR);
        } else if(remoteData.status === 'noplayer') {
            return Promise.reject(NO_ERROR);
        } else {
            PLAYLOG.transaction_id = remoteData.transaction_id;
            callback_url = remoteData.redir + '&t=' +  Date.now();
            callbackstart_url = remoteData.start
            switch (remoteData.type) {
                case 'iframe':
                    playerIframe.source = remoteData.ad_iframe;
                    return playerIframe.load();
                case 'html':
                    playerHTML.source = remoteData.ad_html;
                    return playerHTML.load();
                default: fetchDataMedia(remoteData);
            }
        }
    })
    /*
    .then(player => {
        PLAYLOG.date_begin = Date.now();
        if (callbackstart_url != undefined){                    
            console.log(callbackstart_url)
            recordLog('', callbackstart_url);
        }
        return player.play();
    });
    */
}

async function fetchDataMedia(remoteData) {
    const response  = await fetch("/media/" + remoteData.ad_id + "/expired.json")
    const data = await response.json();
    let fileType = data.type;
    let source = "/media/" + remoteData.ad_id + "/" + data.media;
    let duration = data.duration;
  //  console.log(source)
    switch (fileType) {
    case 'video':
        playerVideo.source = source;
        playerVideo.time = duration;
        return playerVideo.load();
    case 'image':
        playerImage.source = source;
        if (media.time != 0){
            playerImage.time = duration;
        } else {
            playerImage.time = 10;
        }
        return playerImage.load();
    }
}

function recordLog(localURL, remoteURL) {
    return new Promise(resolve => {
        // let canResolve = false;
        let canResolve = true;

        /* postLocalLog(localURL).then(() => console.log('Local log recorded'))
            .catch(e => canResolve ? resolve() : canResolve = true)
            .finally(() => canResolve ? resolve() : canResolve = true); */

        postRemoteLog(remoteURL).then(() => console.log('Remote log recorded'))
            .catch(e => canResolve ? resolve() : canResolve = true)
            .finally(() => canResolve ? resolve() : canResolve = true);
    });
}

function postLocalLog(url) {
    PLAYLOG.date_end = Date.now();

    let headers = new Headers();
    headers.append("key", "a0f333b5-1a1b-429e-bde2-7ba263e802b8");
    headers.append("Content-Type", "application/x-www-form-urlencoded");

    var urlencoded = new URLSearchParams();

    for(const key in PLAYLOG) {
        urlencoded.append(key, PLAYLOG[key]);
    }

    const requestOptionsRedir = {
        method: 'POST',
        headers: headers,
        body: urlencoded,
        redirect: 'follow',
    }

    return fetch(url, requestOptionsRedir);
}

function postRemoteLog(url) {
    var myHeaders = new Headers()
    myHeaders.append("Cookie", "tuuid=0808d769-2cac-4e3f-a744-bf90002cbfbd")

    var requestOptionsRedir = {
        mode: 'no-cors',
        method: 'POST',
        headers: myHeaders,
        redirect: 'follow',
    }

    return fetch(url, requestOptionsRedir);
}

var playerIframe = {
    element: document.createElement('iframe'),
    source: "",
    load: () => {
        return new Promise((resolve, reject) => {
            console.log(`Loading iframe for ${playerIframe.source}`);
            if (playerIframe.source === "")
                reject("Empty source for iframe player ")

            playerIframe.element.width = "100%";
            playerIframe.element.height = "100%";
            playerIframe.element.onerror = () => reject("Error loading media");
            playerIframe.element.onload = () => resolve(playerIframe);
            playerIframe.element.src = playerIframe.source;
            document.body.appendChild(playerIframe.element);
        })
    },
    play: () => {
        return new Promise(resolve => {
            const timeout = setTimeout(() => {
                clearTimeout(timeout);
                resolve()
            }, 14500)
        })
    }
}

var playerHTML = {
    element: document.createElement('div'),
    source: "",
    load: () => {
        return new Promise((resolve, reject) => {

            if (playerHTML.source === "")
                reject("Empty source for HTML player");

            playerHTML.element.innerHTML += decodeHTMLEntities(playerHTML.source);
            document.body.appendChild(playerHTML.element);
            resolve(playerHTML);
        })
    },
    play: () => {
        return new Promise(resolve => {
            const timeout = setTimeout(() => {
                clearTimeout(timeout);
                resolve()
            }, 14500)
        })
    }
}

var playerVideo = {
    element: "",
    source: "",
    time: 0,
    load: () => {
        return new Promise((resolve, reject) => {
            playerVideo.element = document.getElementById('video');
            if (playerVideo.source === "")
                reject("Empty source for video player");

            playerVideo.element.onerror = () => reject(`Error on load video ${playerVideo.element.error.code} - ${playerVideo.element.error.message}`);
            playerVideo.element.onloadeddata = () => resolve(playerVideo);
            playerVideo.element.autoplay = true;
            playerVideo.element.src = playerVideo.source;

        })
    },
    play: () => {
        return new Promise((resolve, reject) => {
            let hasFinished = false;

            playerVideo.element.onstalled = () => {
                if(!hasFinished) {
                    hasFinished = true;
                    reject('Video player has failed to fetch data');
                }
            }

            playerVideo.element.onended = () => {
                if(!hasFinished) {
                    hasFinished = true;
                    resolve();
                }
            }

            playerVideo.element.ontimeupdate = () => {
                if (!hasFinished)
                    if (this.currentTime >= (playerVideo.time - 500)) {
                        hasFinished = true;
                        resolve();
                    }
            }
        })
    }
}

var playerImage = {
    element: "",
    source: "",
    time: 0,
    load: () => {
        playerImage.element = document.getElementById('imagem');
        return new Promise((resolve, reject) => {

            if (playerImage.source === "")
                reject("Empty source for HTML player")

            playerImage.element.onload = () => resolve(playerImage);
            playerImage.element.onerror = () => reject(`Error on load image`);
            playerImage.element.src = playerImage.source;
        })
    },
    play: () => {
        return new Promise(resolve => {
            playerImage.element.style.opacity = 1;
            const timeout = setTimeout(() => {
                clearTimeout(timeout);
                resolve()
            }, (playerImage.time * 1000) - 500)
        })
    }
}

window.onload = start;

function decodeHTMLEntities(text) {
    let textArea = document.createElement('textarea');
    textArea.innerHTML = text;
    return textArea.value;
}